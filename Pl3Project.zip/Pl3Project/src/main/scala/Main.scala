import Models.{Appointment, AppointmentCreated, AppointmentInfoResult, AppointmentInfoResultAll, Billing, BillingCreated, BillingInfoResult, BillingInfoResultAll, CreateAppointment, CreateBilling, CreateMedication, DeleteAppointment, DeleteBilling, DeleteMedication, GetBillingInfo, GetBillingInfoAllOfThem, GetMedicationInfo, GetMedicationInfoAllOfThem, Medication, MedicationCreated, MedicationInfoResult, MedicationInfoResultAll, UpdateBilling, UpdateMedication, UpdateornotAppointment}
import Reposetriy.{AppointmentRepository, BillingRepository, DoctorRepository, MedicationRepository, PatientRepository, StaffRepository}
import akka.actor.{Actor, ActorSystem, Props}
import akka.actor.{Actor, ActorRef, Props}
import akka.pattern.ask
import akka.util.Timeout

import scala.concurrent.ExecutionContext.Implicits
import src.main.scala.Models.{CreateDoctor, CreatePatient, CreateStaff, DeleteDoctor, DeletePatient, DeleteStaff, DeletedOrNot, Doctor, DoctorCreated, DoctorInfoResult, DoctorInfoResultAll, GetDoctorInfo, GetDoctorInfoAllOfThem, GetPatientInfo, GetPatientInfoAllOfthem, GetStaffInfo, GetStaffInfoAllOfThem, Patient, PatientCreated, PatientInfoResult, PatientInfoResultAll, Staff, StaffCreated, StaffInfoResult, StaffInfoResultAll, UpdateDoctor, UpdatePatient, UpdateStaff, UpdatedOrNot, UpdateornotPatientS}

import java.sql.Date
import java.text.SimpleDateFormat
import java.util.Scanner
import scala.concurrent.Await
import scala.concurrent.duration.DurationInt


object Main {
  def main(args: Array[String]): Unit = {

    print("Enter 1 if you are admin : ")
    val num1: Int = scala.io.StdIn.readInt()

    if (num1 == 1) {
      val username1 = "Admin"
      val password1 = 123456
      print("Enter you username : ")
      val username = scala.io.StdIn.readLine()
      print("Enter you password : ")
      val password = scala.io.StdIn.readInt()
      if ((username == username1) && (password == password1)) {
        var loop = true
        while (loop) {
          print("Enter 1 for patient or 2 for doctor or 3 for medication or 4 for Staff : ")
          val num2 = scala.io.StdIn.readInt()
          if (num2 == 1) {
            displayAdminMenuForPatient()
            print("Enter your choise : ")
            val choise = scala.io.StdIn.readInt()
            choise match {
              case 1 =>
                addPatient()
              case 2 =>
                removePatient()
              case 3 =>
                changeInfo()
              case 4 =>
                allPatients()
              case 5 =>
                onePatient()
              case 6 =>
                allBillings()
              case 7 =>
              //oneBilling()
              case 8 =>
                oneAppointment()
              case 9 =>
                allAppointment()
              case 10 =>
                loop = false
                println("exitting the program ")




            }
          }
          if (num2 == 2) {
            displayAdminMenuForDoctor()
            print("Enter your choise : ")
            val choise = scala.io.StdIn.readInt()
            choise match {
              case 1 =>
                addDoctor()
              case 2 =>
                removeDoctor()
              case 3 =>
                changeInfoDoc()
              case 4 =>
                allDoctors()
              case 5 =>
                oneDooctor()
              case 6 =>
                loop = false
                println("exitting the program ")

            }
          }
          if (num2 == 3) {
            displayAdminMenuFormediction()
            print("Enter your choise : ")
            val choise = scala.io.StdIn.readInt()
            choise match {
              case 1 =>
                addMedication()
              case 2 =>
                removeMedication()
              case 3 =>
                oneMedication()
              case 4 =>
                allMedications()
              case 5 =>
                changeInfoMedication()
              case 6 =>
                loop = false
                println("exitting the program ")
            }
            if (num2 == 4) {
              displayAdminMenuForStaff()
              print("Enter your choise : ")
              val choise = scala.io.StdIn.readInt()
              choise match {
                case 1 =>
                  addStaff()
                case 2 =>
                  deleteStaff()
                case 3 =>
                  oneStaff()
                case 4 =>
                  allStaff()
                case 5 =>
                  changeInfoStaff()
                case 6 =>
                  loop = false
                  println("exitting the program ")
              }
            }
          }
        }


        //////////////////////////////////////////Main Functions///////////////////////////////////////////
        def displayAdminMenuForPatient(): Unit = {
          // Implement admin menu display
          println("1. addpatient")
          println("2. DeletePatient")
          println("3. UpdatePatient")
          println("4. GetAllPatient")
          println("5. GetPatientByID")
          println("6. allBillings")
          println("7.oneBillingById ")
          println("8.oneAppointment ")
          println("9.allAppointment ")
          println("10.Exit ")

        }

        def displayAdminMenuForDoctor(): Unit = {
          println("1. AddDoctor")
          println("2. DeleteDoctor")
          println("3. UpdateDoctor")
          println("4. GetAllDoctors")
          println("5. GetDoctorByID")
          println("6. Exit")
        }

        def displayAdminMenuFormediction(): Unit = {
          println("1. AddMed")
          println("2. DeleteMed")
          println("3. UpdateMed")
          println("4. GetAllMed")
          println("5. GetMedByID")
          println("6. Exit")
        }

        def displayAdminMenuForStaff(): Unit = {
          println("1. AddStaff")
          println("2. DeleteStaff")
          println("3. UpdateStaff")
          println("4. GetAllStaff")
          println("5. GetStaffByID")
          println("6. Exit")
        }


        def addPatient(): Unit = {
          val system = ActorSystem("PatientSystem")
          try {
            val patientRepository = new PatientRepository()
            val patientActor: ActorRef = system.actorOf(Patient.props(patientRepository), "patientActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            // Example usage: Adding a new patient with more detail
            print("Enter the patient's name: ")
            val name = scala.io.StdIn.readLine()
            print("Enter the patient's age: ")
            val age = scala.io.StdIn.readInt()
            print("Enter the ptient's gender: ")
            val gender = scala.io.StdIn.readLine()
            print("Enter the doctor's  Id: ")
            val doctorId = scala.io.StdIn.readInt()
            println("Enter a date (yyyy-MM-dd): ")
            val scanner = new Scanner(System.in)
            val dateString = scanner.nextLine()
            val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
            val date = new Date(dateFormat.parse(dateString).getTime)
            print("Enter the medicine's price: ")
            val price = scala.io.StdIn.readDouble()
            val addPatientFuture = patientActor ? CreatePatient(name, age, gender)
            val PatientInfoResult = Await.result(addPatientFuture, 5.seconds)
            PatientInfoResult match {
              case PatientCreated(patientId) =>
                addPrice(price, patientId)
                addAppointment(patientId, doctorId, date)
              //println(s"Patient Created wit ID  $patientId ")

              case _ =>
                println("An unexpected response occurred.")
            }

          }
          finally {
            system.terminate()
          }
        }

        def removePatient(): Unit = {
          val system = ActorSystem("PatientSystem")
          try {
            val patientRepository = new PatientRepository()
            val patientActor: ActorRef = system.actorOf(Patient.props(patientRepository), "patientActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            ///
            print("Enter your Patient Id: ")
            val patientId = scala.io.StdIn.readInt()
            removeBilling(patientId)
            removeAppointment(patientId)
            val GetDeleteOrnot = patientActor ? DeletePatient(patientId)
            val deletedPatientInfoResult = Await.result(GetDeleteOrnot, 5.seconds)
            deletedPatientInfoResult match {
              case DeletedOrNot(deleted) =>
                if (deleted) {
                  println("Patient deleted successfully.")
                } else {
                  println("Delete failed or patient not found.")
                }

              case _ =>
                println("An unexpected response occurred.")
            }
          }
          finally {
            system.terminate()
          }
        }

        def changeInfo(): Unit = {
          val system = ActorSystem("PatientSystem")
          try {
            val patientRepository = new PatientRepository()
            val patientActor: ActorRef = system.actorOf(Patient.props(patientRepository), "patientActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            ////
            print("Enter your Patient Id: ")
            val patientId = scala.io.StdIn.readInt()
            print("Enter the patient's new name: ")
            val newName = scala.io.StdIn.readLine()
            print("Enter the patient's new age: ")
            val newAge = scala.io.StdIn.readInt()
            print("Enter the ptient's new gender: ")
            val newGender = scala.io.StdIn.readLine()
            print("Enter the ptient's new price: ")
            val newprice = scala.io.StdIn.readInt()
            print("Enter the doctor's new Id: ")
            val doctorId = scala.io.StdIn.readInt()
            println("Enter a date new (yyyy-MM-dd): ")
            val scanner = new Scanner(System.in)
            val dateString = scanner.nextLine()
            val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
            val date = new Date(dateFormat.parse(dateString).getTime)
            val Update = patientActor ? UpdatePatient(patientId, newName, newAge, newGender)
            val updatedPatientInfo = Await.result(Update, 5.seconds)
            updatedPatientInfo match {
              case UpdateornotPatientS(update) =>
                if (update) {
                  changeBillingInfo(patientId, newprice)
                  changeInfoApp(patientId, doctorId, date)
                  println("Patient Updated Successfully")
                }
                else {
                  println("Updated failed or patient not found.")
                }
              case _ =>
                println("An unexpected response occurred.")
            }
          }
          finally {
            system.terminate()
          }
        }

        def allPatients(): Unit = {
          val system = ActorSystem("PatientSystem")
          try {
            val patientRepository = new PatientRepository()
            val patientActor: ActorRef = system.actorOf(Patient.props(patientRepository), "patientActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            // Get all patient
            val getAllPatientsResponse = patientActor ? GetPatientInfoAllOfthem()
            val PatientInfoResultAll(allPatients) = Await.result(getAllPatientsResponse, 5.seconds)
            //val amount = allBillings()
            if (allPatients.nonEmpty) {
              println("All Patients:")
              allPatients.foreach { case (id, name, age, gender) =>
                println(s"Patient ID: $id, Name: $name, AGE: $age, GENDER: $gender ")
              }
            } else {
              println("No patients found.")
            }
          }
          finally {
            system.terminate()
          }
        }

        def onePatient(): Unit = {
          val system = ActorSystem("PatientSystem")
          try {
            val patientRepository = new PatientRepository()
            val patientActor: ActorRef = system.actorOf(Patient.props(patientRepository), "patientActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            ///
            // Get patient By Id
            print("Enter your Patient Id: ")
            val patientId = scala.io.StdIn.readInt()
            val getPatientInfoResponse = patientActor ? GetPatientInfo(patientId)
            val PatientInfoResult(patientName) = Await.result(getPatientInfoResponse, 5.seconds)
            //val amout = oneBilling(patientId)
            if (patientName.nonEmpty) {
              println("All Patients:")
              patientName.foreach { case (id, name, age, gender) =>
                println(s"Patient ID: $id, Name: $name, AGE: $age, GENDER: $gender")
              }
            } else {
              println("No patient found.")
            }
          }
        }


        def addDoctor(): Unit = {
          val system = ActorSystem("DoctorSystem")
          try {
            val doctorRepository = new DoctorRepository()
            val doctorActor: ActorRef = system.actorOf(Doctor.props(doctorRepository), "doctorActor")
            implicit val timeout: Timeout = Timeout(5.seconds)

            // Example usage: Adding a new doctor
            print("Enter the doctor's name: ")
            val name = scala.io.StdIn.readLine()
            print("Enter the doctor's specialization: ")
            val specialization = scala.io.StdIn.readLine()

            val addDoctorFuture = doctorActor ? CreateDoctor(name, specialization)
            val DoctorCreated(doctorId) = Await.result(addDoctorFuture, 5.seconds)

            println(s"Doctor Created with ID: $doctorId")
          } finally {
            system.terminate()
          }
        }

        def oneDooctor(): Unit = {
          val system = ActorSystem("DoctorSystem")
          try {
            val doctorRepository = new DoctorRepository()
            val doctorActor: ActorRef = system.actorOf(Doctor.props(doctorRepository), "doctorActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            //////
            print("Enter the doctor's ID: ")
            val doctorId = scala.io.StdIn.readInt()
            val getDoctorInfoResponse = doctorActor ? GetDoctorInfo(doctorId)
            val DoctorInfoResult(doctorName) = Await.result(getDoctorInfoResponse, 5.seconds)

            if (doctorName.nonEmpty) {
              println("Doctor:")
              doctorName.foreach { case (id, name, specialiaztion) =>
                println(s"Patient ID: $id, Name: $name, AGE: $specialiaztion")
              }
            } else {
              println("No patient found.")
            }

          }
        }

        def allDoctors(): Unit = {
          val system = ActorSystem("DoctorSystem")
          try {
            val doctorRepository = new DoctorRepository()
            val doctorActor: ActorRef = system.actorOf(Doctor.props(doctorRepository), "doctorActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            //////
            val getAllDoctorsResponse = doctorActor ? GetDoctorInfoAllOfThem()
            val DoctorInfoResultAll(allDoctors) = Await.result(getAllDoctorsResponse, 5.seconds)

            if (allDoctors.nonEmpty) {
              println("All Doctors:")
              allDoctors.foreach { case (id, name) =>
                println(s"Doctor ID: $id, Name: $name")
              }
            } else {
              println("No doctors found.")
            }
          } finally {
            system.terminate()
          }
        }

        def removeDoctor(): Unit = {
          val system = ActorSystem("DoctorSystem")
          try {
            val doctorRepository = new DoctorRepository()
            val doctorActor: ActorRef = system.actorOf(Doctor.props(doctorRepository), "doctorActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            /////////
            print("Enter your Patient Id: ")
            val doctorId = scala.io.StdIn.readInt()
            removeAppointment(doctorId)
            val deleteDoctorResponse = doctorActor ? DeleteDoctor(doctorId)
            val DeletedOrNot(deleted) = Await.result(deleteDoctorResponse, 5.seconds)
            deleted match {
              case true =>
                println("Doctor deleted successfully.")
              case false =>
                println("Delete failed or doctor not found.")
            }
          } finally {
            system.terminate()
          }
        }

        def changeInfoDoc(): Unit = {
          val system = ActorSystem("DoctorSystem")
          try {
            val doctorRepository = new DoctorRepository()
            val doctorActor: ActorRef = system.actorOf(Doctor.props(doctorRepository), "doctorActor")
            implicit val timeout: Timeout = Timeout(5.seconds)
            /////
            print("Enter your Doctor Id: ")
            val doctorId = scala.io.StdIn.readInt()
            print("Enter the Doctor's new name: ")
            val newName = scala.io.StdIn.readLine()
            print("Enter the Doctor's new Specialization: ")
            val newSpecialization = scala.io.StdIn.readLine()
            val updateDoctorResponse = doctorActor ? UpdateDoctor(doctorId, newName, newSpecialization)
            val UpdatedOrNot(update) = Await.result(updateDoctorResponse, 5.seconds)

            if (update) {
              println("Doctor Updated Successfully")
            } else {
              println("Update failed or doctor not found.")
            }
          } finally {
            system.terminate()
          }

        }

      }
      import scala.math.BigDecimal
      def addPrice(Price: BigDecimal, PatientID: Int): Unit = {
        val system = ActorSystem("BillingSystem")
        try {
          val billingRepository = new BillingRepository()
          val billingActor: ActorRef = system.actorOf(Billing.props(billingRepository), "billingActor")
          implicit val timeout: Timeout = Timeout(5.seconds)
          // Example usage: Adding a new patient with more detail

          /*print("Enter the patient's id: ")
      val patientId = scala.io.StdIn.readInt()
      print("Enter the billing's amount: ")
      val amount = scala.io.StdIn.readDouble()*/
          val addBillingFuture = billingActor ? CreateBilling(Price, PatientID)
          val BillingCreatedin = Await.result(addBillingFuture, 5.seconds)
          BillingCreatedin match {
            case BillingCreated(billingId) =>
              println(s"Billing Created with ID  $billingId ")

            case _ =>
              println("An unexpected response occurred.")
          }


        }
        finally {
          system.terminate()
        }
      }

      def removeBilling(patientid: Int): Unit = {
        val system = ActorSystem("BillingSystem")
        try {
          val billingRepository = new BillingRepository()
          val billingActor: ActorRef = system.actorOf(Billing.props(billingRepository), "billingActor")
          implicit val timeout: Timeout = Timeout(5.seconds)
          ///
          //print("Enter your Billing Id: ")
          // val billingId = scala.io.StdIn.readInt()
          val GetDeleteOrnot = billingActor ? DeleteBilling(patientid)
          /*val deletedBillingInfoResult = Await.result(GetDeleteOrnot, 5.seconds)
      deletedBillingInfoResult match {
        case DeletedOrNot(deleted) =>
          if (deleted) {
            //println("Billing de leted successfully.")
          } else {
            //println("Delete failed or Billing not found.")
          }

        case _ =>
         // println("An unexpected response occurred.")
      }*/
        }
        finally {
          system.terminate()
        }
      }

      def changeBillingInfo(patientId: Int, amount: Int): Unit = {
        val system = ActorSystem("BillingSystem")
        try {
          val billingRepository = new BillingRepository()
          val billingActor: ActorRef = system.actorOf(Billing.props(billingRepository), "billingActor")
          implicit val timeout: Timeout = Timeout(5.seconds)
          val Update = billingActor ? UpdateBilling(patientId, amount)
          val updatedPatientInfo = Await.result(Update, 5.seconds)
          updatedPatientInfo match {
            case UpdatedOrNot(update) =>
              if (update) {
                println("Billing Updated Successfully")

              }
              else {
                println("Updated failed or Billing not found.")
              }
            case _ =>
              println("An unexpected response occurred.")
          }
        }
        finally {
          system.terminate()
        }
      }

      /* def oneBilling(): Unit = {
    val system = ActorSystem("BillingsSystem")
    try {
      val billingsRepository = new BillingRepository()
      val billingActor: ActorRef = system.actorOf(Billing.props(billingsRepository), "billingActor")
      implicit val timeout: Timeout = Timeout(5.seconds)

      // Get Billings By Id
      print("Enter your Billings Id: ")
      val billingsId = scala.io.StdIn.readInt()
      val getBillingsInfoResponse = billingActor ? getBillingById(billingsId)
      val billingResult = Await.result(getBillingsInfoResponse, 5.seconds)



      billingResult match {
        case Some(billing: Billing) =>
          println(s"Billing ID: ${billing.id}, Patient ID: ${billing.patientId}, Patient Name: ${billing.patientName}, Amount: ${billing.amount}")
        case None => println("Billing not found.")
      }
    }
  }*/
      def allBillings(): Unit = {
        val system = ActorSystem("BillingSystem")
        try {
          val billingRepository = new BillingRepository()
          val billingActor: ActorRef = system.actorOf(Billing.props(billingRepository), "billingActor")
          implicit val timeout: Timeout = Timeout(5.seconds)
          // Get all billing
          val getAllBillingsResponse = billingActor ? GetBillingInfoAllOfThem()
          val BillingInfoResultAll(allBillings) = Await.result(getAllBillingsResponse, 5.seconds)

          if (allBillings.nonEmpty) {
            println("All Billings:")
            allBillings.foreach { case (patientId, amount, name) =>
              println(s"Patient Name: $name, Patient ID: $patientId, amount: $amount")
            }
          } else {
            println("No Billings found.")
          }
        }
        finally {
          system.terminate()
        }
      }

      def addAppointment(patientId: Int, doctorId: Int, date: Date): Unit = {
        val system = ActorSystem("AppointmentSystem")
        try {
          val appointmentRepository = new AppointmentRepository()
          val appointmentActor: ActorRef = system.actorOf(Appointment.props(appointmentRepository), "appointmentActor")
          implicit val timeout: Timeout = Timeout(5.seconds)

          // Example usage: Adding a new appointment
          /*print("Enter the  patient Id: ")
      val patientId = scala.io.StdIn.readInt()
      print("Enter the  doctor Id: ")
      val doctorId = scala.io.StdIn.readInt()
      println("Enter a date (yyyy-MM-dd): ")
      val scanner = new Scanner(System.in)
      val dateString = scanner.nextLine()
      val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
      val date = new Date(dateFormat.parse(dateString).getTime)*/

          val addAppointmentFuture = appointmentActor ? CreateAppointment(patientId, doctorId, date)
          val AppointmentInfoResult = Await.result(addAppointmentFuture, 5.seconds)

          AppointmentInfoResult match {
            case AppointmentCreated(appointmentId) =>
              println(s"Appointment Created wit ID  $appointmentId ")

            case _ =>
              println("An unexpected response occurred.")
          }
        } finally {
          system.terminate()
        }
      }

      def removeAppointment(patientId: Int): Unit = {
        val system = ActorSystem("AppointmentSystem")
        try {
          val appointmentRepository = new AppointmentRepository()
          val appointmentActor: ActorRef = system.actorOf(Appointment.props(appointmentRepository), "appointmentActor")
          implicit val timeout: Timeout = Timeout(5.seconds)
          ///
          /*print("Enter your Appointment Id: ")
      val appointmentId = scala.io.StdIn.readInt()*/
          val GetDeleteOrnot = appointmentActor ? DeleteAppointment(patientId)
          val deletedAppointmentInfoResult = Await.result(GetDeleteOrnot, 5.seconds)
          deletedAppointmentInfoResult match {
            case DeletedOrNot(deleted) =>
              if (deleted) {
                println("Appointment deleted successfully.")
              } else {
                println("Delete failed or Appointment not found.")
              }

            case _ =>
              println("An unexpected response occurred.")
          }
        }
        finally {
          system.terminate()
        }
      }

      def changeInfoApp(patientId: Int, doctorId: Int, date: Date): Unit = {
        val system = ActorSystem("Appointment System")
        try {
          val appointmentRepository = new AppointmentRepository()
          val appointmentActor: ActorRef = system.actorOf(Appointment.props(appointmentRepository), "patientActor")
          implicit val timeout: Timeout = Timeout(5.seconds)
          ////
          /*print("Enter the  patient Id: ")
      val patientId = scala.io.StdIn.readInt()
      print("Enter the  doctor Id: ")
      val doctorId = scala.io.StdIn.readInt()*/

          ///
          /*println("Enter a date (yyyy-MM-dd): ")
      val scanner = new Scanner(System.in)
      val dateString = scanner.nextLine()
      val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
      //val date = dateFormat.parse(dateString)
      val date = new Date(dateFormat.parse(dateString).getTime)*/


          val Update = appointmentActor ? CreateAppointment(patientId, doctorId, date)


          val updatedAppointmentInfo = Await.result(Update, 5.seconds)
          updatedAppointmentInfo match {
            case UpdateornotAppointment(update) =>
              if (update) {
                println(" Appointment Updated Successfully")

              }
              else {
                println("Updated failed or  appointment not found.")
              }
            case _ =>
              println("An unexpected response occurred.")
          }
        }
        finally {
          system.terminate()
        }
      }

      def allAppointment(): Unit = {
        val system = ActorSystem("AppointmentSystem")
        try {
          val appointmentRepository = new AppointmentRepository()
          val AppointmentActor: ActorRef = system.actorOf(Appointment.props(appointmentRepository), " appointment Actor")
          implicit val timeout: Timeout = Timeout(5.seconds)

          val getAllAppointmentResponse = AppointmentActor ? GetPatientInfoAllOfthem()
          val AppointmentInfoResultAll(allAppointment) = Await.result(getAllAppointmentResponse, 5.seconds)

          if (allAppointment.nonEmpty) {
            println("All Appointments:")
            allAppointment.foreach { case (doctorId, patientId, date) =>
              println(s"Name: $doctorId, AGE: $patientId, GENDER: $date ")
            }
          } else {
            println("No Appointment found.")
          }
        }
        finally {
          system.terminate()
        }

      }

      def oneAppointment(): Unit = {
        val system = ActorSystem(" AppointmentSystem")
        try {
          val appointmentRepository = new AppointmentRepository()
          val appointmentActor: ActorRef = system.actorOf(Appointment.props(appointmentRepository), "appointmentActor")
          implicit val timeout: Timeout = Timeout(5.seconds)
          ///
          // Get patient By Id
          print("Enter your Appointment Id: ")
          val appointmentId = scala.io.StdIn.readInt()
          val getAppointmentInfoResponse = appointmentActor ? GetPatientInfo(appointmentId)
          val AppointmentInfoResult(patientId) = Await.result(getAppointmentInfoResponse, 5.seconds)
          val AppointmentInfoResult(doctorId) = Await.result(getAppointmentInfoResponse, 5.seconds)
          val AppointmentInfoResult(date) = Await.result(getAppointmentInfoResponse, 5.seconds)


          patientId match {
            case Some(patientId) => println(s"Patient Id: $patientId")
            case None => println("Patient not found.")
          }
          doctorId match {
            case Some(doctorId) => println(s" Doctor Id: $doctorId ")
            case None => println("Patient not found.")
          }
          date match {
            case Some(date) => println(s" Date: $date ")
            case None => println("Patient not found.")
          }
        }

      }
    }

    def addMedication(): Unit = {
      val system = ActorSystem("MedicationSystem")
      try {
        val medicationRepository = new MedicationRepository()
        val medicationActor: ActorRef = system.actorOf(Medication.props(medicationRepository), "medicationActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        // Example usage: Adding a new medication
        print("Enter the patient's Id: ")
        val patientId = scala.io.StdIn.readInt()
        print("Enter the medication's name: ")
        val name = scala.io.StdIn.readLine()
        print("Enter the medication's description: ")
        val description = scala.io.StdIn.readLine()
        println("Enter a date (yyyy-MM-dd): ")
        val scanner = new Scanner(System.in)
        val dateString = scanner.nextLine()
        val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
        val date = new Date(dateFormat.parse(dateString).getTime)

        val addMedicationFuture = medicationActor ? CreateMedication(patientId, name, description, date)
        val MedicationCreated(medicationId) = Await.result(addMedicationFuture, 5.seconds)

        println(s"Medication Created with ID: $medicationId")
      } finally {
        system.terminate()
      }
    }

    def removeMedication(): Unit = {
      val system = ActorSystem("MedicationSystem")
      try {
        val medicationRepository = new MedicationRepository()
        val medicationActor: ActorRef = system.actorOf(Medication.props(medicationRepository), "medicationActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        print("Enter the patient's ID: ")
        val patientId = scala.io.StdIn.readInt()
        val deleteMedicationResponse = medicationActor ? DeleteMedication(patientId)
        //val DeletedOrNot(deleted) = Await.result(deleteMedicationResponse, 5.seconds)
        /*if (deleted) {
        println("Medication deleted successfully.")
      } else {
        println("Delete failed or medication not found.")
      }*/
      } finally {
        system.terminate()
      }
    }

    def oneMedication(): Unit = {
      val system = ActorSystem("MedicationSystem")
      try {
        val medicationRepository = new MedicationRepository()
        val medicationActor: ActorRef = system.actorOf(Medication.props(medicationRepository), "medicationActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        print("Enter the medication's ID: ")
        val medicationId = scala.io.StdIn.readInt()
        val getMedicationInfoResponse = medicationActor ? GetMedicationInfo(medicationId)
        val MedicationInfoResult(medicationName, medicationDescription, date) = Await.result(getMedicationInfoResponse, 5.seconds)

        (medicationName, medicationDescription, date) match {
          case (Some(name), Some(description), Some(date)) =>
            println(s"Medication found - Name: $name, Description: $description, Date: $date")
          case _ =>
            println("No medication found with the given ID")
        }
      } finally {
        system.terminate()
      }
    }

    def allMedications(): Unit = {
      val system = ActorSystem("MedicationSystem")
      try {
        val medicationRepository = new MedicationRepository()
        val medicationActor: ActorRef = system.actorOf(Medication.props(medicationRepository), "medicationActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        val getAllMedicationsResponse = medicationActor ? GetMedicationInfoAllOfThem()
        val MedicationInfoResultAll(allMedications) = Await.result(getAllMedicationsResponse, 5.seconds)

        if (allMedications.nonEmpty) {
          println("All Medications:")
          allMedications.foreach { case (id, name, description, date) =>
            println(s"Medication ID: $id, Name: $name, Description: $description,Date: $date")
          }
        } else {
          println("No medications found.")
        }
      } finally {
        system.terminate()
      }
    }

    def changeInfoMedication(): Unit = {
      val system = ActorSystem("MedicationSystem")
      try {
        val medicationRepository = new MedicationRepository()
        val medicationActor: ActorRef = system.actorOf(Medication.props(medicationRepository), "medicationActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        print("Enter the Medication's ID: ")
        val medicationId = scala.io.StdIn.readInt()
        print("Enter the Medication's new name: ")
        val newName = scala.io.StdIn.readLine()
        print("Enter the Medication's new description: ")
        val newDescription = scala.io.StdIn.readLine()
        println("Enter a date new (yyyy-MM-dd): ")
        val scanner = new Scanner(System.in)
        val dateString = scanner.nextLine()
        val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
        val newDate = new Date(dateFormat.parse(dateString).getTime)
        val updateMedicationResponse = medicationActor ? UpdateMedication(medicationId, newName, newDescription, newDate)
        val UpdatedOrNot(update) = Await.result(updateMedicationResponse, 5.seconds)

        if (update) {
          println("Medication Updated Successfully")
        } else {
          println("Update failed or medication not found.")
        }
      } finally {
        system.terminate()
      }
    }

    def addStaff(): Unit = {
      val system = ActorSystem("StaffSystem")
      try {
        val staffRepository = new StaffRepository()
        val staffActor: ActorRef = system.actorOf(Staff.props(staffRepository), "staffActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        // Example usage: Adding a new staff
        print("Enter the staff's name: ")
        val name = scala.io.StdIn.readLine()
        print("Enter the staff's role: ")
        val role = scala.io.StdIn.readLine()

        val addStaffFuture = staffActor ? CreateStaff(name, role)
        val StaffCreated(staffId) = Await.result(addStaffFuture, 5.seconds)

        println(s"Staff Created with ID: $staffId")
      } finally {
        system.terminate()
      }
    }

    def oneStaff(): Unit = {
      val system = ActorSystem("StaffSystem")
      try {
        val staffRepository = new StaffRepository()
        val staffActor: ActorRef = system.actorOf(Staff.props(staffRepository), "staffActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        print("Enter the staff's ID: ")
        val staffId = scala.io.StdIn.readInt()
        val getStaffInfoResponse = staffActor ? GetStaffInfo(staffId)
        val StaffInfoResult(staffName, staffRole) = Await.result(getStaffInfoResponse, 5.seconds)

        (staffName, staffRole) match {
          case (Some(name), Some(role)) =>
            println(s"Staff found - Name: $name, Role: $role")
          case _ =>
            println("No staff found with the given ID")
        }
      } finally {
        system.terminate()
      }
    }

    def deleteStaff(): Unit = {
      val system = ActorSystem("StaffSystem")
      try {
        val staffRepository = new StaffRepository()
        val staffActor: ActorRef = system.actorOf(Staff.props(staffRepository), "staffActor")
        implicit val timeout: Timeout = Timeout(5.seconds)

        print("Enter the staff's ID: ")
        val staffId = scala.io.StdIn.readInt()
        val deleteStaffResponse = staffActor ? DeleteStaff(staffId)
        val DeletedOrNot(deleted) = Await.result(deleteStaffResponse, 5.seconds)

        if (deleted) {
          println("Staff deleted successfully.")
        } else {
          println("Delete failed or staff not found.")
        }
      } finally {
        system.terminate()
      }
    }
  }

  def allStaff(): Unit = {
    val system = ActorSystem("StaffSystem")
    try {
      val staffRepository = new StaffRepository()
      val staffActor: ActorRef = system.actorOf(Staff.props(staffRepository), "staffActor")
      implicit val timeout: Timeout = Timeout(5.seconds)

      val getAllStaffResponse = staffActor ? GetStaffInfoAllOfThem()
      val StaffInfoResultAll(allStaff) = Await.result(getAllStaffResponse, 5.seconds)

      if (allStaff.nonEmpty) {
        println("All Staff:")
        allStaff.foreach { case (id, name, role) =>
          println(s"Staff ID: $id, Name: $name, Role: $role")
        }
      } else {
        println("No staff found.")
      }
    } finally {
      system.terminate()
    }
  }

  def changeInfoStaff(): Unit = {
    val system = ActorSystem("StaffSystem")
    try {
      val staffRepository = new StaffRepository()
      val staffActor: ActorRef = system.actorOf(Staff.props(staffRepository), "staffActor")
      implicit val timeout: Timeout = Timeout(5.seconds)

      print("Enter the Staff's ID: ")
      val staffId = scala.io.StdIn.readInt()
      print("Enter the Staff's new name: ")
      val newName = scala.io.StdIn.readLine()
      print("Enter the Staff's new role: ")
      val newRole = scala.io.StdIn.readLine()
      val updateStaffResponse = staffActor ? UpdateStaff(staffId, newName, newRole)
      val UpdatedOrNot(update) = Await.result(updateStaffResponse, 5.seconds)

      if (update) {
        println("Staff Updated Successfully")
      } else {
        println("Update failed or staff not found.")
      }
    } finally {
      system.terminate()
    }
  }
}






