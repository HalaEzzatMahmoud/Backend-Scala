package src.main.scala.Models
import Reposetriy.DoctorRepository
import akka.actor.{Actor, Props}

case class CreateDoctor(name: String, specialization: String)
case class DoctorCreated(doctorId: Int)
case class DoctorInfoResult(doctor:  List[(Int, String,String)])
case class GetDoctorInfo(doctorId: Int)
case class GetDoctorInfoAllOfThem()
case class DoctorInfoResultAll(doctors: List[(Int, String)])
case class DeleteDoctor(doctorId: Int)
case class DeletedOrNot(deleted: Boolean)
case class UpdateDoctor(doctorId: Int, newName: String,newSpecialization: String)
case class UpdatedOrNot(updated: Boolean)

class Doctor(doctorRepository: DoctorRepository) extends Actor {

  def receive: Receive = {
    case CreateDoctor(name, specialization) =>
      val doctorId = doctorRepository.saveDoctor(name,specialization)
      sender() ! DoctorCreated(doctorId)


    case GetDoctorInfo(doctorId) =>
      val doctorInfo = doctorRepository.getDoctorById(doctorId)
      sender() ! DoctorInfoResult(doctorInfo)


    case GetDoctorInfoAllOfThem() =>
      val doctorInfo = doctorRepository.getDoctorAll()
      sender() ! DoctorInfoResultAll(doctorInfo)

    case DeleteDoctor(doctorId) =>
      val deleted = doctorRepository.deleteDoctor(doctorId)
      sender() ! DeletedOrNot(deleted)

    case UpdateDoctor(doctorId, newName,newSpecialization) =>
      val updated = doctorRepository.updateDoctor(doctorId,newName,newSpecialization)
      sender() ! UpdatedOrNot(updated)
  }
}

object Doctor {
  def props(doctorRepository: DoctorRepository): Props = Props(new Doctor(doctorRepository))
}
