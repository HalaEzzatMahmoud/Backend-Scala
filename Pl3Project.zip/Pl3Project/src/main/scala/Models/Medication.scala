package Models

import Reposetriy._
import akka.actor.{Actor, Props}

import java.sql.Date

case class CreateMedication(patientId: Int, medicationName: String, dosage: String, prescriptionDate: Date)
case class MedicationCreated(medicationId: Int)
case class MedicationInfoResult(medicationName: Option[String], dosage: Option[String], prescriptionDate: Option[String])
case class GetMedicationInfo(medicationId: Int)
case class GetMedicationInfoAllOfThem()
case class MedicationInfoResultAll(medications: List[(Int, String, String,Date)])
case class DeleteMedication(medicationId: Int)
case class DeletedMedicationOrNot(deleted: Boolean)
case class UpdateMedication(medicationId: Int, newMedicationName: String, newDosage: String, newPrescriptionDate: Date)
case class UpdatedMedicationOrNot(updated: Boolean)

class Medication(medicationRepository: MedicationRepository) extends Actor {

  def receive: Receive = {
    case CreateMedication(patientId, medicationName, dosage, prescriptionDate) =>
      val medicationId = medicationRepository.saveMedication(patientId, medicationName, dosage, prescriptionDate)
      sender() ! MedicationCreated(medicationId)

    case GetMedicationInfo(medicationId) =>
      val medicationInfo = medicationRepository.getMedicationById(medicationId)
      val result = medicationInfo.map(info => MedicationInfoResult(Some(info._2), Some(info._2), Some(info._2)))
      sender() ! result.getOrElse(MedicationInfoResult(None, None, None))

    case GetMedicationInfoAllOfThem() =>
      val medications = medicationRepository.getMedicationAll()
      sender() ! MedicationInfoResultAll(medications)

    case DeleteMedication(patientId) =>
      val deleted = medicationRepository.deleteMedication(patientId)
      sender() ! DeletedMedicationOrNot(deleted)

    case UpdateMedication(medicationId, newMedicationName, newDosage, newPrescriptionDate) =>
      val updated = medicationRepository.updateMedication(medicationId, newMedicationName, newDosage,newPrescriptionDate)
      sender() ! UpdatedMedicationOrNot(updated)
  }
}



object Medication {
  def props(medicationRepository: MedicationRepository): Props = Props(new Medication(medicationRepository))
}
