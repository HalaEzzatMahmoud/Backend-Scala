package Models

import Reposetriy.BillingRepository
import akka.actor.{Actor, Props}

import scala.math.BigDecimal

case class CreateBilling(amount: BigDecimal , patientId: Int)
case class BillingCreated(billingId: Int)
case class BillingInfoResult(patientID: Option[Int], patientName: Option[String],amount: Option[BigDecimal])
case class GetBillingInfo(billingId: Int)
case class GetBillingInfoAllOfThem()
case class BillingInfoResultAll(billings: List[(Int,BigDecimal,String)])
case class DeleteBilling(billingId: Int)
case class DeletedOrNot(deleted: Boolean)
case class UpdateBilling(billingId: Int, newAmount: Int)
case class UpdatedOrNot(updated: Boolean)

class Billing(billingRepository: BillingRepository) extends Actor {

  def receive: Receive = {
    case CreateBilling(amount, patientId) =>
      val billingId = billingRepository.saveBilling(amount, patientId)
      sender() ! BillingCreated(billingId)

    //    case GetBillingInfo(billingId) =>
    //      val billingInfo = billingRepository.getBillingById(billingId)
    //      sender() ! BillingInfoResult(billingInfo)

    case GetBillingInfo(billingId) =>
      val billingInfo = billingRepository.getBillingById(billingId)
      val result = billingInfo.map {
        case (patientId, patientName, amount) =>
          BillingInfoResult(Some(patientId), Some(patientName), Some(amount))
      }
      sender() ! result

    case GetBillingInfoAllOfThem() =>
      val billings = billingRepository.getBillingAll()
      sender() ! BillingInfoResultAll(billings)

    case DeleteBilling(patientId) =>
      val deleted = billingRepository.deleteBilling(patientId)
      sender() ! DeletedOrNot(deleted)

    case UpdateBilling(patientId, newAmount) =>
      val updated = billingRepository.updateBilling(patientId,newAmount)
      sender() ! UpdatedOrNot(updated)
  }
}

object Billing {
  def props(billingRepository: BillingRepository): Props = Props(new Billing(billingRepository))
}
