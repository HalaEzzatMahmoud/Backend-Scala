package src.main.scala.Models

import Reposetriy.StaffRepository
import akka.actor.{Actor, Props}

case class CreateStaff(name: String, role: String)
case class StaffCreated(staffId: Int)
case class StaffInfoResult(name: Option[String], role: Option[String])
case class GetStaffInfo(staffId: Int)
case class GetStaffInfoAllOfThem()
case class StaffInfoResultAll(staffList: List[(Int, String, String)])
case class DeleteStaff(staffId: Int)
case class UpdateStaff(staffId: Int, newName: String, newRole: String)


class Staff(staffRepository: StaffRepository) extends Actor {

  def receive: Receive = {
    case CreateStaff(name, role) =>
      val staffId = staffRepository.saveStaff(name, role)
      sender() ! StaffCreated(staffId)

    case GetStaffInfo(staffId) =>
      val staffInfo = staffRepository.getStaffById(staffId)
      val result = staffInfo.map(info => StaffInfoResult(Some(info._2), Some(info._2)))
      sender() ! result.getOrElse(StaffInfoResult(None, None))

    case GetStaffInfoAllOfThem() =>
      val staffList = staffRepository.getStaffAll()
      sender() ! StaffInfoResultAll(staffList)

    case DeleteStaff(staffId) =>
      val deleted = staffRepository.deleteStaff(staffId)
      sender() ! DeletedOrNot(deleted)

    case UpdateStaff(staffId, newName, newRole) =>
      val updated = staffRepository.updateStaff(staffId, newName, newRole)
      sender() ! UpdatedOrNot(updated)
  }
}

object Staff {
  def props(staffRepository: StaffRepository): Props = Props(new Staff(staffRepository))
}