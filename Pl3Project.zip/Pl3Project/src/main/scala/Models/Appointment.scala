package Models
import Reposetriy.AppointmentRepository
import akka.actor.{Actor, Props}
import src.main.scala.Models.{DeletedOrNot}

import java.sql.Date
case class CreateAppointment( patientID :Int ,doctorID: Int, date:Date)
case class  AppointmentCreated (appointmentId: Int)
case class  AppointmentInfoResult(name:  Option[String])
case class GetAppointmentInfo(appointmentId: Int)
case class GetAppointmentInfoAllOfthem()
case class AppointmentInfoResultAll(value: List[(String,String,Date)])
case class  DeleteAppointment(appointmentId : Int )
//
case class UpdateAppointment(appointmentId: Int, newDoctorId:Int, newPatientId: Int,  newDate:Int )
case class UpdateornotAppointment(Updated:Boolean)




class Appointment(appointmentRepository:  AppointmentRepository) extends Actor {

  def receive: Receive = {
    case CreateAppointment(patientId, doctorId, date ) =>
      val appointmentId = appointmentRepository . saveAppointment(patientId, doctorId, date)
      sender() ! AppointmentCreated(appointmentId)
    /////////////////
    case GetAppointmentInfo(appointmentId) =>
      val appointmentInfo = appointmentRepository.getAppointmentById(appointmentId)
      sender() ! AppointmentInfoResult(appointmentInfo )
    /////////////////
    /*case GetAppointmentInfoAllOfthem() =>
      val appointmentInfo = appointmentRepository.getAppointmentAll()
      sender() ! AppointmentInfoResultAll(appointmentInfo)*/
    ////////////////
    case DeleteAppointment(appointmentId) =>
      val appointmentInfo = appointmentRepository .deleteAppointment(appointmentId)
      sender() ! DeletedOrNot(appointmentInfo)
    ////////////////
    case UpdateAppointment(appointmentId, newDoctorId, newPatientId,  newDate ) =>
      val appointmentInfo = appointmentRepository .updateAppointment (appointmentId, newDoctorId, newPatientId,  newDate )
      sender() ! UpdateornotAppointment(appointmentInfo)
  }
}














object Appointment {
  def props(appointmentRepository: AppointmentRepository): Props = Props(new Appointment(appointmentRepository))

}
