package src.main.scala.Models
import scala.concurrent.duration._
import Reposetriy.PatientRepository
import akka.actor.{Actor, Props}
case class CreatePatient(name: String,age: Int,gender: String)
case class PatientCreated(patientId: Int)
case class PatientInfoResult(patients: List[(Int, String,Int,String)])
case class GetPatientInfo(patientId: Int)
case class GetPatientInfoAllOfthem()
case class PatientInfoResultAll(patients: List[(Int, String,Int,String)])
case class  DeletePatient(PatientId : Int )

case class UpdatePatient(patientId: Int, newName: String,newAge: Int, newGender: String)
case class UpdateornotPatientS(Updated:Boolean)



class Patient(patientRepository: PatientRepository) extends Actor  {

  override def receive: Receive = {
    case CreatePatient(name,age,gender) =>
      val patientId = patientRepository.savePatient(name,age,gender)
      sender() ! PatientCreated(patientId)

    case GetPatientInfo(patientId) =>
      val patientInfo = patientRepository.getPatientById(patientId)
      sender() ! PatientInfoResult(patientInfo)


    case GetPatientInfoAllOfthem() =>
      val patientInfo = patientRepository.getPatientAll()
      sender() ! PatientInfoResultAll(patientInfo)

    case DeletePatient(patientId) =>
      val patientInfo = patientRepository.deletePatient(patientId)
      sender() ! DeletedOrNot(patientInfo)

    case UpdatePatient(patientId, newName, newAge, newGender) =>
      val patientInfo = patientRepository.updatePatient(patientId, newName, newAge, newGender)
      sender() ! UpdateornotPatientS(patientInfo)
  }



}
object Patient {
  def props(patientRepository: PatientRepository): Props = Props(new Patient(patientRepository))
}


