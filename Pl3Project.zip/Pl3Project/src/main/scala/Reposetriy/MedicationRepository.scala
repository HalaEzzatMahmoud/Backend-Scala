package Reposetriy

import DatabaseConnect.{DatabaseConfing, DatabaseConnector}

import java.sql.{Date, ResultSet, SQLException, Statement}

class MedicationRepository {
  val config = new DatabaseConfing()
  val connector = new DatabaseConnector(config)

  def saveMedication(patientId:Int, medicationName: String, dosage: String, prescriptionDate: Date): Int = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val result = statement.executeUpdate(
        s"INSERT INTO Medication (PatientID,MedicationName, Dosage ,PrescriptionDate) VALUES ('$patientId','$medicationName','$patientId' '$dosage','$prescriptionDate')",
        Statement.RETURN_GENERATED_KEYS
      )

      if (result > 0) {
        val generatedKeys: ResultSet = statement.getGeneratedKeys()
        if (generatedKeys.next()) {
          return generatedKeys.getInt(1)
        }
      }

      throw new RuntimeException("Failed to retrieve the generated medication ID.")
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def getMedicationById(medicationId: Int): Option[(String, String, Date)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT Name, Description,PrescriptionDate FROM Medication WHERE MedicationId = $medicationId")

      if (resultSet.next()) {
        val name = resultSet.getString("Name")
        val description = resultSet.getString("Description")
        val date = resultSet.getDate("Date")
        Some((name, description,date))
      } else {
        None
      }
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def getMedicationAll(): List[(Int, String, String,Date)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT * FROM Medication")
      var medicationList: List[(Int, String, String,Date)] = List()
      while (resultSet.next()) {
        val medicationId = resultSet.getInt("MedicationId")
        val name = resultSet.getString("Name")
        val description = resultSet.getString("Description")
        val date = resultSet.getDate("Date")

        medicationList = medicationList :+ (medicationId, name, description,date)
      }
      medicationList
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def updateMedication(medicationId: Int, newName: String, newDescription: String,newPrescriptionDate: Date): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val updateQuery = s"UPDATE Medication SET Name = '$newName', Description = '$newDescription',newPrescriptionDate = '$newPrescriptionDate' WHERE MedicationId = $medicationId"
      val rowsAffected: Int = statement.executeUpdate(updateQuery)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error updating medication with ID $medicationId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def deleteMedication(patientId: Int): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val query = s"DELETE FROM Medication WHERE MedicationID = $patientId"
      val rowsAffected: Int = statement.executeUpdate(query)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error deleting medication with ID $patientId: ${e.getMessage}")
        false
    } finally {
      try {
        if (connector != null) {
          // your existing code inside the if block
          connector.closeConnection()
        }
      }
    }
  }
}
