package Reposetriy

import DatabaseConnect.{DatabaseConfing, DatabaseConnector}
import akka.japi.Option.some

import java.sql.Date
import java.sql.{ResultSet, SQLException, Statement}



class AppointmentRepository {
  val config = new DatabaseConfing()
  val connector = new DatabaseConnector(config)

  def saveAppointment(patientId: Int, doctorId: Int, date: Date): Int = {

    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val result = statement.executeUpdate(s"INSERT INTO Appointment ( PatientID, DoctorID, Date) VALUES ( '$patientId','$doctorId','$date')", Statement.RETURN_GENERATED_KEYS)

      if (result > 0) {
        val generatedKeys: ResultSet = statement.getGeneratedKeys()
        if (generatedKeys.next()) {
          return generatedKeys.getInt(1)
        }
      }
      throw new RuntimeException("Failed to retrieve generated appointment.")

    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }

  }

  ///////////
  def getAppointmentById(appointmentId: Int): Option[String] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s" SELECT Doctor.Name AS DoctorName ,Patient.Name AS PatientName ,date   FROM  Doctor JOIN  Appointment ON  Doctor.DoctorID =  Appointment.doctorId  JOIN  Patient ON   Patient.PatientID =  Appointment.doctorId ; WHERE AppointmentId = $appointmentId")

      if (resultSet.next()) {
        val DoctorName = resultSet.getString("DoctorName")

        val PatientName = resultSet.getString("PatientName ")

        val date = resultSet.getDate("Date")
        val formattedResult = s"Doctor:$DoctorName, Patient:$PatientName,date:$date"
        some(formattedResult)
      }
      else {
        None // No patient found with the given ID
      }
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def getAppointmentAll(): List[(String,String,Date)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s" SELECT Doctor.Name AS DoctorName, Patient.Name AS PatientName FROM Doctor JOIN Appointment ON Doctor.DoctorID = Appointment.doctorId JOIN Patient ON Patient.PatientID = Appointment.patientId; ")

      var appointments: List[( String,String, Date)] = List()
      while (resultSet.next()) {
        //        val appointmentId = resultSet.getInt("Id")
        //        val patientId = resultSet.getInt("PatientId")

        //        val doctorId = resultSet.getInt("DoctorId")
        //        val date = resultSet.getDate("Date")
        //       appointments = appointments :+ (appointmentId,patientId, doctorId, date)
        val DoctorName = resultSet.getString("DoctorName")
        val PatientName = resultSet.getString("PatientName ")
        val date = resultSet.getDate("Date")
        appointments = appointments :+ (DoctorName , PatientName,date)

      }
      appointments
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def  updateAppointment(appointmentId: Int, newDoctorId:Int, newPatientId: Int,  newDate:Int): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val updateQuery =
        s"UPDATE Appointment SET DoctorId = '$newDoctorId ', PatientId = '$newPatientId', Date = '$newDate' WHERE   appointmentId= $appointmentId"

      val rowsAffected: Int = statement.executeUpdate(updateQuery)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error updating patient with ID $appointmentId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def deleteAppointment(patientId: Int): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val query = s"DELETE FROM appointment WHERE PatientID = $patientId"
      val rowsAffected: Int = statement.executeUpdate(query)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error deleting Appointment with ID $patientId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

}
