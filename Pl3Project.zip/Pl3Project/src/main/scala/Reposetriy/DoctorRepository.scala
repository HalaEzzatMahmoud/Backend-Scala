package Reposetriy

import DatabaseConnect.{DatabaseConfing, DatabaseConnector}

import java.sql.{ResultSet, SQLException, Statement}

class DoctorRepository {
  val config = new DatabaseConfing()
  val connector = new DatabaseConnector(config)


  def saveDoctor(name: String, specialization: String): Int = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      // Corrected SQL query with proper single quotes and column names
      val result = statement.executeUpdate(
        s"INSERT INTO Doctor (Name, Specialization) VALUES ('$name', '$specialization')",
        Statement.RETURN_GENERATED_KEYS
      )

      if (result > 0) {
        val generatedKeys: ResultSet = statement.getGeneratedKeys()
        if (generatedKeys.next()) {
          return generatedKeys.getInt(1)
        }
      }

      throw new RuntimeException("Failed to retrieve the generated doctor ID.")
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }


  def getDoctorById(doctorId: Int): List[(Int, String, String)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT * FROM Doctor WHERE DoctorId = $doctorId")
      var doctor: List[(Int, String, String)] = List()

      while (resultSet.next()) {
        val doctorId = resultSet.getInt("doctorId")
        val name = resultSet.getString("Name")
        val spec= resultSet.getString("Spechalization")
        doctor = doctor :+ (doctorId, name,spec )
      }
      doctor
    }
     finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }


  def getDoctorAll(): List[(Int, String)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT * FROM Doctor")
      var doctors: List[(Int, String)] = List()
      while (resultSet.next()) {
        val doctorId = resultSet.getInt("DoctorId")
        val name = resultSet.getString("Name")
        doctors = doctors :+ (doctorId, name)
      }
      doctors
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def updateDoctor(doctorId: Int, newName: String,newSpecialization: String ): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val updateQuery = s"UPDATE Doctor SET Name = '$newName', Specialization = '$newSpecialization' WHERE DoctorId = $doctorId"
      val rowsAffected: Int = statement.executeUpdate(updateQuery)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error updating doctor with ID $doctorId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }


  def deleteDoctor(doctorId: Int): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val query = s"DELETE Doctor, Appointment FROM Doctor LEFT JOIN Appointment ON Doctor.DoctorID = Appointment.doctorId WHERE Doctor.DoctorID = $doctorId;"
      val rowsAffected: Int = statement.executeUpdate(query)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error deleting doctor with ID $doctorId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }
}


