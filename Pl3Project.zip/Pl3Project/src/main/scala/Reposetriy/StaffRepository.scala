package Reposetriy

import DatabaseConnect.{DatabaseConfing, DatabaseConnector}

import java.sql.{ResultSet, SQLException, Statement}

class StaffRepository {
  val config = new DatabaseConfing()
  val connector = new DatabaseConnector(config)

  def saveStaff(name: String, role: String): Int = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val result = statement.executeUpdate(
        s"INSERT INTO Staff (Name, Role) VALUES ('$name', '$role')",
        Statement.RETURN_GENERATED_KEYS
      )

      if (result > 0) {
        val generatedKeys: ResultSet = statement.getGeneratedKeys()
        if (generatedKeys.next()) {
          return generatedKeys.getInt(1)
        }
      }

      throw new RuntimeException("Failed to retrieve the generated staff ID.")
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def getStaffById(staffId: Int): Option[(String, String)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT Name, Role FROM Staff WHERE StaffId = $staffId")

      if (resultSet.next()) {
        val name = resultSet.getString("Name")
        val role = resultSet.getString("Role")

        Some((name, role))
      } else {
        None
      }
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def getStaffAll(): List[(Int, String, String)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT * FROM Staff")
      var staffList: List[(Int, String, String)] = List()
      while (resultSet.next()) {
        val staffId = resultSet.getInt("StaffId")
        val name = resultSet.getString("Name")
        val role = resultSet.getString("Role")
        staffList = staffList :+ (staffId, name, role)
      }
      staffList
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def updateStaff(staffId: Int, newName: String, newRole: String): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val updateQuery = s"UPDATE Staff SET Name = '$newName', Role = '$newRole' WHERE StaffId = $staffId"
      val rowsAffected: Int = statement.executeUpdate(updateQuery)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error updating staff with ID $staffId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def deleteStaff(staffId: Int): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val query = s"DELETE FROM Staff WHERE StaffId = $staffId"
      val rowsAffected: Int = statement.executeUpdate(query)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error deleting staff with ID $staffId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }
}