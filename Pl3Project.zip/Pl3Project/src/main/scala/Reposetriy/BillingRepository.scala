package Reposetriy

import DatabaseConnect.{DatabaseConfing, DatabaseConnector}
import scala.math.BigDecimal
import java.sql.{ResultSet, SQLException, Statement}

class BillingRepository {
  val config = new DatabaseConfing()
  val connector = new DatabaseConnector(config)


  def saveBilling(amount: BigDecimal, patientID: Int): Int = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      // Corrected SQL query with proper single quotes and column names
      val result = statement.executeUpdate(
        s"INSERT INTO Billing (Amount,PatientID) VALUES ('$amount' , '$patientID')",
        Statement.RETURN_GENERATED_KEYS
      )

      if (result > 0) {
        val generatedKeys: ResultSet = statement.getGeneratedKeys()
        if (generatedKeys.next()) {
          return generatedKeys.getInt(1)
        }
      }

      throw new RuntimeException("Failed to retrieve the generated doctor ID.")
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }


  def getBillingById(billingId: Int): Option[(Int, String, BigDecimal)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT Patient.PatientID, Patient.Name AS PatientName, Billing.Amount FROM Patient JOIN Billing ON Patient.PatientID = Billing.PatientID WHERE BillingId = $billingId")

      if (resultSet.next()) {
        val patientId = resultSet.getInt("PatientID")
        val patientName = resultSet.getString("PatientName")
        val amount = resultSet.getBigDecimal("Amount")

        Some(patientId, patientName, amount)
      } else {
        None
      }
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }


  def getBillingAll(): List[(Int, BigDecimal, String)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT Patient.PatientID, Patient.Name AS PatientName, Billing.Amount FROM Patient JOIN Billing ON Patient.PatientID = Billing.PatientID;")
      var billings: List[(Int, BigDecimal, String)] = List()
      while (resultSet.next()) {
        val patientID = resultSet.getInt("PatientID")
        val amount = resultSet.getBigDecimal("Amount")
        val patientName = resultSet.getString("PatientName")
        billings = billings :+ (patientID, amount, patientName)
      }
      billings
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def updateBilling(patientId: Int, newAmount: Int ): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val updateQuery = s"UPDATE Billing SET Amount = '$newAmount' WHERE patientId = $patientId"
      val rowsAffected: Int = statement.executeUpdate(updateQuery)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error updating Billing with ID $patientId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }


  def deleteBilling(patientId: Int): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val query = s"DELETE FROM Billing WHERE PatientId = $patientId"
      val rowsAffected: Int = statement.executeUpdate(query)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error deleting Billing with ID $patientId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }
}

