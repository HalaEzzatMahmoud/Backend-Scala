package Reposetriy

import DatabaseConnect.{DatabaseConfing, DatabaseConnector}

import java.sql.{ResultSet, SQLException, Statement}
import scala.:+

class PatientRepository() {
  val config = new DatabaseConfing()
  val connector = new DatabaseConnector(config)

  def savePatient(name: String, age: Int, gender: String): Int    = {

    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val result = statement.executeUpdate(s"INSERT INTO patient ( Name,Age,Gender) VALUES ( '$name','$age','$gender')", Statement.RETURN_GENERATED_KEYS)

      if (result > 0) {
        val generatedKeys: ResultSet = statement.getGeneratedKeys()
        if (generatedKeys.next()) {
          return generatedKeys.getInt(1)
        }
      }
      throw new RuntimeException("Failed to retrieve generated patient ID.")

    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }

  }


  def getPatientById(patientId: Int): List[(Int, String, Int, String)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT * FROM Patient WHERE PatientId = $patientId")
      var patients: List[(Int, String, Int, String)] = List()
      while (resultSet.next()) {
        val patientId = resultSet.getInt("PatientId")
        val name = resultSet.getString("Name")
        val age = resultSet.getInt("Age")
        val gender = resultSet.getString("Gender")
        patients = patients :+ (patientId, name, age, gender)
      }
      patients
    }
    finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }

  def getPatientAll(): List[(Int, String, Int, String)] = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val resultSet: ResultSet = statement.executeQuery(s"SELECT * FROM Patient")
      var patients: List[(Int, String, Int, String)] = List()
      while (resultSet.next()) {
        val patientId = resultSet.getInt("PatientId")
        val name = resultSet.getString("Name")
        val age = resultSet.getInt("Age")
        val gender = resultSet.getString("Gender")
        patients = patients :+ (patientId, name, age, gender)
      }
      patients
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }




  def updatePatient(patientId: Int, newName: String, newAge: Int, newGender: String): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()

      val updateQuery =
        s"UPDATE Patient SET Name = '$newName', Age = $newAge, Gender = '$newGender' WHERE PatientId = $patientId"

      val rowsAffected: Int = statement.executeUpdate(updateQuery)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error updating patient with ID $patientId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }


  def deletePatient(patientId: Int): Boolean = {
    try {
      connector.openConnection()
      val statement: Statement = connector.createStatement()
      val query = s"DELETE FROM Patient WHERE PatientId = $patientId"
      //val query = s"DELETE Patient, Medication FROM Patient LEFT JOIN Medication ON Medication.PatientID = Medication.patientId WHERE Patient.PatientID = $patientId;"
      val rowsAffected: Int = statement.executeUpdate(query)
      rowsAffected > 0
    } catch {
      case e: SQLException =>
        println(s"Error deleting patient with ID $patientId: ${e.getMessage}")
        false
    } finally {
      if (connector != null) {
        connector.closeConnection()
      }
    }
  }




}
