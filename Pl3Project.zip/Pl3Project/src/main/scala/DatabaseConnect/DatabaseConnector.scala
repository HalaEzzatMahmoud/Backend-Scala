package DatabaseConnect

import java.sql.{Connection, DriverManager, Statement, ResultSet}

class DatabaseConnector(config: DatabaseConfing) {
  private var connection: Connection = _

  def openConnection(): Unit = {
    Class.forName("com.mysql.cj.jdbc.Driver")
    connection = DriverManager.getConnection(config.url, config.username, config.password)
  }

  def closeConnection(): Unit = {
    if (connection != null && !connection.isClosed) {
      connection.close()
    }
  }

  def createStatement(): Statement = {
    if (connection == null || connection.isClosed) {
      throw new IllegalStateException("Connection is closed. Call openConnection() before creating a statement.")
    }
    connection.createStatement()
  }

  def executeQuery(query: String): ResultSet = {
    val statement = createStatement()
    val resultSet = statement.executeQuery(query)
    statement.close()
    resultSet
  }
}
