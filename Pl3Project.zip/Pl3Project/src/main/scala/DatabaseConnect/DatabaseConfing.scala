package DatabaseConnect

class DatabaseConfing {

  val dbName = "hospital"
  val url = s"jdbc:mysql://localhost:3306/$dbName"
  val username = "root";
  val password = "542002hala"
}
